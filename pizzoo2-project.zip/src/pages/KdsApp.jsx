import React from 'react';
import { ChefHat, Volume2, VolumeX, PlusCircle, ArrowLeft, Filter } from 'lucide-react';
import { useKds } from '../context/KdsContext';
import { KdsCard } from '../components/KdsCard';

export const KdsApp = ({ onExitKds }) => {
  const { 
    orders, 
    rawOrdersCount, 
    filter, 
    setFilter, 
    soundEnabled, 
    setSoundEnabled, 
    addOrder 
  } = useKds();

  const handleSimulateTestOrder = () => {
    const tableNumbers = ['01', '03', '05', '08', 'TAKEOUT'];
    const randomTable = tableNumbers[Math.floor(Math.random() * tableNumbers.length)];

    addOrder({
      tableNo: randomTable,
      type: randomTable === 'TAKEOUT' ? 'TAKEOUT' : 'DINE_IN',
      customerName: randomTable === 'TAKEOUT' ? 'Phone Takeout Customer' : `Table ${randomTable}`,
      notes: 'Extra cheese, well-done crust',
      items: [
        { name: 'Classic Margherita', size: 'Large (12")', crust: 'Neapolitan Thin (00 Flour)', quantity: 1 },
        { name: 'Loaded Cheese Fries', size: 'Full', quantity: 1 }
      ]
    });
  };

  return (
    <div className="min-h-screen bg-[#0A0500] text-white p-4 md:p-8 font-sans selection:bg-trattoria-red">
      {/* Top Header Bar */}
      <header className="max-w-7xl mx-auto border-b border-white/10 pb-6 mb-8 flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <button 
            onClick={onExitKds}
            className="p-2.5 bg-white/5 hover:bg-white/10 rounded-xl border border-white/10 text-white/70 hover:text-white transition-colors"
            title="Return to Customer Menu"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <ChefHat className="w-7 h-7 text-trattoria-gold" />
              <h1 className="font-serif text-3xl font-black text-white">Pizzoo Kitchen KDS</h1>
            </div>
            <p className="text-xs text-trattoria-gold/80 tracking-widest uppercase">
              Kitchen Display System · Real-Time Order Management
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-3">
          {/* Sound Toggle */}
          <button
            onClick={() => setSoundEnabled(!soundEnabled)}
            className={`p-2.5 rounded-xl border text-xs font-bold uppercase tracking-wider flex items-center gap-2 transition-all ${
              soundEnabled 
                ? 'bg-emerald-950/60 border-emerald-500/50 text-emerald-300' 
                : 'bg-white/5 border-white/10 text-white/40'
            }`}
            title="Toggle Chime Sound"
          >
            {soundEnabled ? <Volume2 className="w-4 h-4 text-emerald-400" /> : <VolumeX className="w-4 h-4" />}
            <span className="hidden sm:inline">{soundEnabled ? 'Sound Enabled' : 'Muted'}</span>
          </button>

          {/* Test Order Simulator */}
          <button
            onClick={handleSimulateTestOrder}
            className="bg-trattoria-red hover:bg-trattoria-redHover text-white px-4 py-2.5 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-1.5 shadow-red-glow transition-all"
          >
            <PlusCircle className="w-4 h-4" />
            <span>New Test Order 🍕</span>
          </button>
        </div>
      </header>

      {/* Filter Tabs & Counter */}
      <div className="max-w-7xl mx-auto mb-8 flex flex-wrap justify-between items-center gap-4 bg-white/[0.03] p-3 rounded-2xl border border-white/10">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-trattoria-gold ml-2" />
          <span className="text-xs text-trattoria-gold uppercase tracking-wider font-bold mr-2">Filter:</span>
          
          <button
            onClick={() => setFilter('ALL')}
            className={`px-4 py-2 rounded-xl text-xs uppercase font-bold tracking-wider transition-all ${
              filter === 'ALL' 
                ? 'bg-trattoria-gold text-trattoria-wood font-black shadow-gold-glow' 
                : 'text-white/60 hover:text-white'
            }`}
          >
            All Orders ({rawOrdersCount})
          </button>

          <button
            onClick={() => setFilter('DINE_IN')}
            className={`px-4 py-2 rounded-xl text-xs uppercase font-bold tracking-wider transition-all ${
              filter === 'DINE_IN' 
                ? 'bg-trattoria-red text-white font-black shadow-red-glow' 
                : 'text-white/60 hover:text-white'
            }`}
          >
            Dine-In Tables
          </button>

          <button
            onClick={() => setFilter('TAKEOUT')}
            className={`px-4 py-2 rounded-xl text-xs uppercase font-bold tracking-wider transition-all ${
              filter === 'TAKEOUT' 
                ? 'bg-blue-600 text-white font-black' 
                : 'text-white/60 hover:text-white'
            }`}
          >
            Phone Takeouts
          </button>
        </div>

        {/* Legend */}
        <div className="flex items-center gap-4 text-[11px] text-white/60 uppercase font-sans pr-2">
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500" /> &lt; 10m (New)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-amber-500" /> &gt; 10m (In Oven)
          </span>
          <span className="flex items-center gap-1.5">
            <span className="w-2.5 h-2.5 rounded-full bg-red-500 animate-ping" /> &gt; 20m (Delayed)
          </span>
        </div>
      </div>

      {/* Orders Grid */}
      <main className="max-w-7xl mx-auto">
        {orders.length === 0 ? (
          <div className="text-center py-28 bg-white/[0.02] border border-white/5 rounded-3xl">
            <ChefHat className="w-16 h-16 text-white/20 mx-auto mb-4" />
            <h3 className="font-serif text-2xl text-white/60">No active kitchen orders</h3>
            <p className="text-xs text-white/40 font-sans uppercase tracking-widest mt-1">
              Table QR scans and phone orders will appear here in real-time.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {orders.map((order) => (
              <KdsCard key={order.id} order={order} />
            ))}
          </div>
        )}
      </main>
    </div>
  );
};
