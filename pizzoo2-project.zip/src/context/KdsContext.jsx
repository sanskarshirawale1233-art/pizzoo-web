import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { playKdsOrderChime } from '../utils/soundEffects';

const STORAGE_KEY = 'pizzoo_orders_db_v1';
const CHANNEL_NAME = 'pizzoo_kds_realtime_channel';

const DEFAULT_ORDERS = [
  {
    id: 'ORD-101',
    tableNo: '04',
    type: 'DINE_IN',
    customerName: 'Table 04',
    createdAt: new Date(Date.now() - 6 * 60000).toISOString(),
    status: 'RECEIVED', // 'RECEIVED' | 'IN_OVEN' | 'READY' | 'SERVED'
    notes: 'Extra crispy base',
    items: [
      { id: 1, name: 'Classic Margherita', size: 'Large (12")', crust: 'Thin Neapolitan', sauceLevel: 'Normal Sauce', toppings: ['Fresh Basil'], quantity: 2, price: 450 },
      { id: 2, name: 'Loaded Cheese Fries', size: 'Standard', quantity: 1, price: 150 }
    ]
  },
  {
    id: 'ORD-102',
    tableNo: 'TAKEOUT',
    type: 'TAKEOUT',
    customerName: 'Marco (Phone Order)',
    phone: '+1234567890',
    createdAt: new Date(Date.now() - 14 * 60000).toISOString(),
    status: 'IN_OVEN',
    notes: 'Cut into 8 slices',
    items: [
      { id: 3, name: 'Tandoori Chicken Special', size: 'Medium (10")', crust: 'Stuffed Cheese Crust', sauceLevel: 'Extra Sauce', toppings: ['Jalapeños'], quantity: 1, price: 580 }
    ]
  }
];

const KdsContext = createContext(null);

export const KdsProvider = ({ children }) => {
  // Initialize from LocalStorage or default fallback
  const [orders, setOrders] = useState(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch (e) {
      console.warn('LocalStorage read error:', e);
    }
    return DEFAULT_ORDERS;
  });

  const [filter, setFilter] = useState('ALL'); // 'ALL' | 'DINE_IN' | 'TAKEOUT'
  const [soundEnabled, setSoundEnabled] = useState(true);

  // Helper to persist orders to LocalStorage
  const persistOrders = (updatedOrders) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(updatedOrders));
    } catch (e) {
      console.error('LocalStorage write error:', e);
    }
  };

  // Trigger Audio Chime
  const triggerAudioChime = useCallback(() => {
    if (soundEnabled) {
      playKdsOrderChime();
    }
  }, [soundEnabled]);

  // Real-Time Cross-Window Synchronization via BroadcastChannel & LocalStorage Event
  useEffect(() => {
    let broadcastChannel;

    // 1. BroadcastChannel API for instant cross-tab messages
    if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
      broadcastChannel = new BroadcastChannel(CHANNEL_NAME);
      broadcastChannel.onmessage = (event) => {
        const data = event.data;
        if (data && data.type === 'NEW_ORDER') {
          setOrders(data.orders);
          triggerAudioChime();
        } else if (data && data.type === 'SYNC_ORDERS') {
          setOrders(data.orders);
        }
      };
    }

    // 2. Storage event listener fallback (for multi-window cross-domain / iframe)
    const handleStorageEvent = (e) => {
      if (e.key === STORAGE_KEY && e.newValue) {
        try {
          const newOrders = JSON.parse(e.newValue);
          setOrders(newOrders);
        } catch (err) {
          console.error('Storage sync parse error:', err);
        }
      }
    };

    window.addEventListener('storage', handleStorageEvent);

    return () => {
      if (broadcastChannel) broadcastChannel.close();
      window.removeEventListener('storage', handleStorageEvent);
    };
  }, [triggerAudioChime]);

  // 1. Add Order (Called from Table QR Scan or Takeout)
  const addOrder = useCallback((newOrderData) => {
    const newOrder = {
      id: `ORD-${Math.floor(1000 + Math.random() * 9000)}`,
      createdAt: new Date().toISOString(),
      status: 'RECEIVED',
      ...newOrderData
    };

    setOrders((prev) => {
      const updated = [newOrder, ...prev];
      persistOrders(updated);

      // Broadcast to other windows/tabs (e.g. /.admin)
      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel(CHANNEL_NAME);
          bc.postMessage({ type: 'NEW_ORDER', newOrder, orders: updated });
          bc.close();
        } catch (e) {
          console.warn('BroadcastChannel error:', e);
        }
      }

      return updated;
    });

    triggerAudioChime();
    return newOrder;
  }, [triggerAudioChime]);

  // 2. Advance Status: RECEIVED -> IN_OVEN -> READY -> SERVED
  const advanceOrderStatus = useCallback((orderId) => {
    const statusFlow = ['RECEIVED', 'IN_OVEN', 'READY', 'SERVED'];
    
    setOrders((prevOrders) => {
      const updated = prevOrders.map((order) => {
        if (order.id !== orderId) return order;
        const currentIndex = statusFlow.indexOf(order.status);
        const nextStatus = statusFlow[currentIndex + 1] || order.status;
        return { ...order, status: nextStatus };
      });

      persistOrders(updated);

      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel(CHANNEL_NAME);
          bc.postMessage({ type: 'SYNC_ORDERS', orders: updated });
          bc.close();
        } catch (e) {}
      }

      return updated;
    });
  }, []);

  // 3. Revert Status
  const revertOrderStatus = useCallback((orderId) => {
    const statusFlow = ['RECEIVED', 'IN_OVEN', 'READY', 'SERVED'];
    
    setOrders((prevOrders) => {
      const updated = prevOrders.map((order) => {
        if (order.id !== orderId) return order;
        const currentIndex = statusFlow.indexOf(order.status);
        const prevStatus = currentIndex > 0 ? statusFlow[currentIndex - 1] : order.status;
        return { ...order, status: prevStatus };
      });

      persistOrders(updated);

      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel(CHANNEL_NAME);
          bc.postMessage({ type: 'SYNC_ORDERS', orders: updated });
          bc.close();
        } catch (e) {}
      }

      return updated;
    });
  }, []);

  // 4. Archive Order
  const archiveOrder = useCallback((orderId) => {
    setOrders((prevOrders) => {
      const updated = prevOrders.filter((o) => o.id !== orderId);
      persistOrders(updated);

      if (typeof window !== 'undefined' && 'BroadcastChannel' in window) {
        try {
          const bc = new BroadcastChannel(CHANNEL_NAME);
          bc.postMessage({ type: 'SYNC_ORDERS', orders: updated });
          bc.close();
        } catch (e) {}
      }

      return updated;
    });
  }, []);

  // Filtered view
  const filteredOrders = orders.filter((order) => {
    if (filter === 'DINE_IN') return order.type === 'DINE_IN';
    if (filter === 'TAKEOUT') return order.type === 'TAKEOUT';
    return true;
  });

  const value = {
    orders: filteredOrders,
    rawOrdersCount: orders.length,
    allOrders: orders,
    filter,
    setFilter,
    soundEnabled,
    setSoundEnabled,
    addOrder,
    advanceOrderStatus,
    revertOrderStatus,
    archiveOrder
  };

  return <KdsContext.Provider value={value}>{children}</KdsContext.Provider>;
};

export const useKds = () => {
  const context = useContext(KdsContext);
  if (!context) {
    throw new Error('useKds must be used within a KdsProvider');
  }
  return context;
};
