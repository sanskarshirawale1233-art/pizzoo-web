import React, { createContext, useContext, useState, useEffect } from 'react';
import { useKds } from './KdsContext';

const CartContext = createContext(null);

export const CartProvider = ({ children }) => {
  const [cart, setCart] = useState([]);
  const [tableId, setTableId] = useState(null);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [activeOrderTracker, setActiveOrderTracker] = useState(null);
  const [isUpiModalOpen, setIsUpiModalOpen] = useState(false);

  const { addOrder, allOrders } = useKds();

  // Dynamically extract tableId from URL path or query parameters
  useEffect(() => {
    const handleUrlDetection = () => {
      const pathname = window.location.pathname;
      const searchParams = new URLSearchParams(window.location.search);

      // Check URL pattern /table/05
      const tableMatch = pathname.match(/\/table\/([^\/]+)/i);
      if (tableMatch && tableMatch[1]) {
        setTableId(tableMatch[1]);
      } else if (searchParams.get('table')) {
        setTableId(searchParams.get('table'));
      }
    };

    handleUrlDetection();
    window.addEventListener('popstate', handleUrlDetection);
    return () => window.removeEventListener('popstate', handleUrlDetection);
  }, []);

  // Update active order tracker state from KDS context updates
  useEffect(() => {
    if (activeOrderTracker?.id) {
      const updatedOrder = allOrders.find(o => o.id === activeOrderTracker.id);
      if (updatedOrder) {
        setActiveOrderTracker(updatedOrder);
      }
    }
  }, [allOrders, activeOrderTracker?.id]);

  const addToCart = (item) => {
    setCart((prevCart) => {
      const cartItemId = item.cartItemId || `${item.id}-${item.size || 'default'}-${item.crust || ''}-${Date.now()}`;
      return [...prevCart, { ...item, cartItemId, quantity: item.quantity || 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (cartItemId) => {
    setCart((prev) => prev.filter((item) => item.cartItemId !== cartItemId));
  };

  const updateQuantity = (cartItemId, delta) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.cartItemId === cartItemId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean)
    );
  };

  const clearCart = () => setCart([]);

  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  // Submit order directly to kitchen display system (for Dine-In QR scans)
  const submitDineInOrder = (customerNotes = '') => {
    if (cart.length === 0) return null;

    const orderPayload = {
      tableNo: tableId || 'DINE-IN',
      type: 'DINE_IN',
      customerName: tableId ? `Tavolo ${tableId}` : 'Dine-In Customer',
      notes: customerNotes,
      items: cart.map(i => ({
        name: i.name,
        size: i.size || 'Standard',
        crust: i.crust || 'Neapolitan Thin',
        sauceLevel: i.sauceLevel || 'Normal',
        toppings: i.toppings || [],
        quantity: i.quantity,
        price: i.price
      }))
    };

    const newOrder = addOrder(orderPayload);
    setActiveOrderTracker(newOrder);
    clearCart();
    setIsCartOpen(false);
    return newOrder;
  };

  // Generate formatted Call-to-Order text summary for phone calls
  const generateCallSummary = () => {
    const header = tableId 
      ? `🍕 *PIZZOO ORDINE TAVOLO ${tableId}*\n` 
      : `🍕 *PIZZOO ORDINE DA ASPORTO (Takeout Order)*\n`;

    const itemsText = cart.map((i, index) => {
      const details = [];
      if (i.size) details.push(`Taglia: ${i.size}`);
      if (i.crust) details.push(`Crosta: ${i.crust}`);
      if (i.toppings?.length) details.push(`Toppings: ${i.toppings.join(', ')}`);
      
      const detailStr = details.length ? `\n   └ (${details.join(' | ')})` : '';
      return `${index + 1}. ${i.quantity}x ${i.name} - ₹${i.price * i.quantity}${detailStr}`;
    }).join('\n');

    const totalText = `\n\n💰 *Totale: ₹${subtotal}*`;
    const paymentNote = `\n📌 *Pagamento:* Contanti / QR UPI al Tavolo`;

    return `${header}\n${itemsText}${totalText}${paymentNote}`;
  };

  // Submit Call-to-Order (Takeout) and add to KDS
  const submitCallOrder = () => {
    if (cart.length === 0) return;

    const orderPayload = {
      tableNo: 'TAKEOUT',
      type: 'TAKEOUT',
      customerName: 'Asporto (Phone Order)',
      notes: 'Call-to-Order via Telephone',
      items: cart.map(i => ({
        name: i.name,
        size: i.size || 'Standard',
        crust: i.crust || 'Thin',
        quantity: i.quantity,
        price: i.price
      }))
    };

    const newOrder = addOrder(orderPayload);
    setActiveOrderTracker(newOrder);
    clearCart();
    setIsCartOpen(false);

    // Trigger direct telephone call
    window.location.href = 'tel:7738009029';
  };

  // Submit via WhatsApp
  const submitWhatsAppOrder = () => {
    if (cart.length === 0) return;
    const summary = generateCallSummary();

    const orderPayload = {
      tableNo: tableId || 'TAKEOUT',
      type: tableId ? 'DINE_IN' : 'TAKEOUT',
      customerName: tableId ? `Tavolo ${tableId} (WhatsApp)` : 'Asporto (WhatsApp)',
      notes: 'Order sent via WhatsApp',
      items: cart.map(i => ({
        name: i.name,
        size: i.size || 'Standard',
        crust: i.crust || 'Thin',
        quantity: i.quantity,
        price: i.price
      }))
    };

    const newOrder = addOrder(orderPayload);
    setActiveOrderTracker(newOrder);
    clearCart();
    setIsCartOpen(false);

    const waUrl = `https://wa.me/917738009029?text=${encodeURIComponent(summary)}`;
    window.open(waUrl, '_blank');
  };

  const value = {
    cart,
    tableId,
    setTableId,
    isCartOpen,
    setIsCartOpen,
    addToCart,
    removeFromCart,
    updateQuantity,
    clearCart,
    subtotal,
    submitDineInOrder,
    submitCallOrder,
    submitWhatsAppOrder,
    generateCallSummary,
    activeOrderTracker,
    setActiveOrderTracker,
    isUpiModalOpen,
    setIsUpiModalOpen
  };

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
};

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within a CartProvider');
  }
  return context;
};
