import React, { useState, useEffect } from 'react';
import { KdsProvider } from './context/KdsContext';
import { CartProvider } from './context/CartContext';
import { CustomerApp } from './pages/CustomerApp';
import { KdsApp } from './pages/KdsApp';
import { KdsAdminModal } from './components/KdsAdminModal';

export const App = () => {
  const [currentView, setCurrentView] = useState('customer'); // 'customer' | 'kds'
  const [isAdminAuthOpen, setIsAdminAuthOpen] = useState(false);

  // Detect obscured admin route when user types /.admin, /admin, or /cucina in URL
  useEffect(() => {
    const checkAdminRoute = () => {
      const path = window.location.pathname.toLowerCase();
      const hash = window.location.hash.toLowerCase();

      if (path.includes('.admin') || path.includes('/admin') || path.includes('/cucina') || hash.includes('.admin') || hash.includes('admin')) {
        setIsAdminAuthOpen(true);
      }
    };

    checkAdminRoute();
    window.addEventListener('popstate', checkAdminRoute);
    window.addEventListener('hashchange', checkAdminRoute);
    return () => {
      window.removeEventListener('popstate', checkAdminRoute);
      window.removeEventListener('hashchange', checkAdminRoute);
    };
  }, []);

  const handleExitKds = () => {
    setCurrentView('customer');
    if (window.history.pushState) {
      window.history.pushState(null, '', '/');
    }
  };

  return (
    <KdsProvider>
      <CartProvider>
        {currentView === 'kds' ? (
          <KdsApp onExitKds={handleExitKds} />
        ) : (
          <CustomerApp />
        )}

        {/* Secret PIN Authorization Modal triggered by URL route /.admin */}
        <KdsAdminModal 
          isOpen={isAdminAuthOpen}
          onClose={() => {
            setIsAdminAuthOpen(false);
            if (window.history.pushState) {
              window.history.pushState(null, '', '/');
            }
          }}
          onAuthenticated={() => {
            setIsAdminAuthOpen(false);
            setCurrentView('kds');
          }}
        />
      </CartProvider>
    </KdsProvider>
  );
};

export default App;
