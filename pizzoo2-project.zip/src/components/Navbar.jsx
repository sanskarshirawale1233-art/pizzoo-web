import React, { useState } from 'react';
import { useCart } from '../context/CartContext';
import { ShoppingBag, Phone, Menu, X, QrCode } from 'lucide-react';

export const Navbar = () => {
  const { cart, tableId, setIsCartOpen } = useCart();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const cartCount = cart.reduce((total, item) => total + item.quantity, 0);

  return (
    <nav className="fixed top-0 left-0 right-0 z-50 h-[70px] bg-[#0A0602]/95 backdrop-blur-md border-b border-trattoria-gold/20 px-4 md:px-8 flex items-center justify-between">
      {/* Brand Logo & Tagline */}
      <a href="#home" className="flex items-center gap-3 group">
        <img 
          src="/logo.png" 
          alt="Pizzoo Logo" 
          className="h-11 object-contain filter drop-shadow-[0_0_12px_rgba(240,165,0,0.4)] group-hover:scale-105 transition-transform" 
          onError={(e) => { e.target.style.display = 'none'; }}
        />
        <div>
          <span className="font-serif text-2xl font-black tracking-wide text-white group-hover:text-trattoria-gold transition-colors">
            PIZZOO
          </span>
          <span className="block text-[9px] font-sans tracking-[0.25em] text-trattoria-gold uppercase">
            Italian Pizzeria
          </span>
        </div>
      </a>

      {/* Dine-In Table Badge */}
      {tableId && (
        <div className="hidden sm:flex items-center gap-2 bg-trattoria-red/20 border border-trattoria-red/40 px-3 py-1 rounded-full text-xs font-sans tracking-widest text-trattoria-cream animate-pulse">
          <QrCode className="w-3.5 h-3.5 text-trattoria-gold" />
          <span>TABLE {tableId}</span>
        </div>
      )}

      {/* Nav Links */}
      <ul className="hidden md:flex items-center gap-8 font-sans text-xs tracking-widest uppercase text-white/70">
        <li>
          <a href="#home" className="hover:text-trattoria-gold transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-trattoria-gold hover:after:w-full after:transition-all">
            Home
          </a>
        </li>
        <li>
          <a href="#menu" className="hover:text-trattoria-gold transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-trattoria-gold hover:after:w-full after:transition-all">
            Menu
          </a>
        </li>
        <li>
          <a href="#about" className="hover:text-trattoria-gold transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-trattoria-gold hover:after:w-full after:transition-all">
            Our Story
          </a>
        </li>
        <li>
          <a href="#contact" className="hover:text-trattoria-gold transition-colors relative py-1 after:content-[''] after:absolute after:bottom-0 after:left-0 after:w-0 after:h-[2px] after:bg-trattoria-gold hover:after:w-full after:transition-all">
            Contact Us
          </a>
        </li>
      </ul>

      {/* Actions */}
      <div className="flex items-center gap-3">
        {/* Call-to-Order Telephone Link */}
        <a 
          href="tel:7738009029" 
          className="hidden sm:flex items-center gap-2 bg-gradient-to-r from-trattoria-red to-trattoria-terracotta text-white px-4 py-2 rounded-full font-sans text-xs tracking-wider uppercase font-semibold hover:shadow-red-glow transition-all transform hover:-translate-y-0.5"
        >
          <Phone className="w-3.5 h-3.5" />
          <span>Call: 7738009029</span>
        </a>

        {/* Cart Drawer Trigger */}
        <button 
          onClick={() => setIsCartOpen(true)}
          className="relative p-2.5 bg-trattoria-wood/80 border border-trattoria-gold/30 text-white rounded-full hover:border-trattoria-gold transition-all"
        >
          <ShoppingBag className="w-5 h-5 text-trattoria-gold" />
          {cartCount > 0 && (
            <span className="absolute -top-1 -right-1 bg-trattoria-red text-white text-[10px] font-black font-sans w-5 h-5 rounded-full flex items-center justify-center border-2 border-[#0A0602] animate-bounce">
              {cartCount}
            </span>
          )}
        </button>

        {/* Mobile Hamburger Toggle */}
        <button 
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden p-2 text-white hover:text-trattoria-gold"
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden fixed top-[70px] left-0 right-0 bg-[#0A0602]/98 border-b border-trattoria-gold/20 p-6 flex flex-col gap-4 font-sans text-sm tracking-widest uppercase z-40">
          {tableId && (
            <div className="flex items-center gap-2 text-trattoria-gold bg-trattoria-gold/10 p-3 rounded-lg border border-trattoria-gold/20">
              <QrCode className="w-4 h-4" />
              <span>Table Ordering: Table {tableId}</span>
            </div>
          )}
          <a href="#home" onClick={() => setMobileMenuOpen(false)} className="hover:text-trattoria-gold py-2 border-b border-white/10">Home</a>
          <a href="#menu" onClick={() => setMobileMenuOpen(false)} className="hover:text-trattoria-gold py-2 border-b border-white/10">Menu</a>
          <a href="#about" onClick={() => setMobileMenuOpen(false)} className="hover:text-trattoria-gold py-2 border-b border-white/10">Our Story</a>
          <a href="#contact" onClick={() => setMobileMenuOpen(false)} className="hover:text-trattoria-gold py-2 border-b border-white/10">Contact Us</a>
          <a 
            href="tel:7738009029" 
            className="flex items-center justify-center gap-2 bg-trattoria-red text-white py-3 rounded-lg font-bold mt-2"
          >
            <Phone className="w-4 h-4" />
            <span>Call to Order (7738009029)</span>
          </a>
        </div>
      )}
    </nav>
  );
};
