import React, { useState } from 'react';
import { X, Trash2, Phone, QrCode, Send, MessageCircle, CreditCard } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const CartSidebar = () => {
  const {
    cart,
    tableId,
    isCartOpen,
    setIsCartOpen,
    removeFromCart,
    updateQuantity,
    subtotal,
    submitDineInOrder,
    submitCallOrder,
    submitWhatsAppOrder,
    setIsUpiModalOpen
  } = useCart();

  const [customerNotes, setCustomerNotes] = useState('');

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-[1500] bg-black/70 backdrop-blur-sm flex justify-end animate-fadeIn">
      <div className="w-full max-w-md bg-[#0F0A05] border-l border-trattoria-gold/20 h-full flex flex-col justify-between shadow-2xl text-white">
        
        {/* Header */}
        <div className="p-5 border-b border-white/10 flex items-center justify-between">
          <div>
            <h3 className="font-serif text-2xl font-bold text-white">Your Basket</h3>
            <span className="font-sans text-[10px] tracking-widest uppercase text-trattoria-gold">
              {tableId ? `Table ${tableId} · Dine-In Order` : 'Takeout Order'}
            </span>
          </div>
          <button 
            onClick={() => setIsCartOpen(false)}
            className="text-white/60 hover:text-white p-2 rounded-full hover:bg-white/10 transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Table Indicator Badge */}
        {tableId && (
          <div className="bg-trattoria-red/20 border-y border-trattoria-red/40 px-5 py-2.5 flex items-center justify-between text-xs font-sans text-trattoria-cream">
            <div className="flex items-center gap-2">
              <QrCode className="w-4 h-4 text-trattoria-gold" />
              <span>Ordering for <strong>Table {tableId}</strong></span>
            </div>
            <span className="text-[10px] bg-trattoria-red px-2 py-0.5 rounded font-bold">DINE-IN</span>
          </div>
        )}

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-5 space-y-3">
          {cart.length === 0 ? (
            <div className="text-center py-20 text-white/40 font-sans uppercase tracking-widest text-xs">
              <span className="block text-4xl mb-3">🍕</span>
              Your basket is empty
            </div>
          ) : (
            cart.map((item) => (
              <div 
                key={item.cartItemId} 
                className="bg-white/[0.04] border border-white/10 rounded-xl p-3.5 flex items-center justify-between gap-3 hover:border-trattoria-gold/30 transition-all"
              >
                <div className="flex-1">
                  <div className="font-sans text-sm font-bold text-white">{item.name}</div>
                  <div className="text-[10px] text-trattoria-gold font-sans mt-0.5">
                    {item.size} {item.crust && `| ${item.crust}`}
                  </div>
                  {item.toppings && item.toppings.length > 0 && (
                    <div className="text-[10px] text-white/50 italic mt-0.5">
                      + {item.toppings.join(', ')}
                    </div>
                  )}
                  <div className="font-serif text-sm font-bold text-trattoria-gold mt-1">
                    ₹{item.price * item.quantity}
                  </div>
                </div>

                {/* Quantity Controls */}
                <div className="flex items-center gap-2 bg-white/5 px-2 py-1 rounded-lg border border-white/10">
                  <button 
                    onClick={() => updateQuantity(item.cartItemId, -1)}
                    className="w-6 h-6 rounded flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10"
                  >
                    -
                  </button>
                  <span className="font-sans text-xs font-bold w-4 text-center">{item.quantity}</span>
                  <button 
                    onClick={() => updateQuantity(item.cartItemId, 1)}
                    className="w-6 h-6 rounded flex items-center justify-center text-white/70 hover:text-white hover:bg-white/10"
                  >
                    +
                  </button>
                </div>

                <button 
                  onClick={() => removeFromCart(item.cartItemId)}
                  className="text-white/30 hover:text-trattoria-red p-1 transition-colors"
                >
                  <Trash2 className="w-4 h-4" />
                </button>
              </div>
            ))
          )}
        </div>

        {/* Footer Actions */}
        {cart.length > 0 && (
          <div className="p-5 border-t border-white/10 bg-[#0A0500] space-y-4">
            {/* Customer Kitchen Note Input */}
            <div>
              <input
                type="text"
                placeholder="General notes for kitchen / waiter..."
                value={customerNotes}
                onChange={(e) => setCustomerNotes(e.target.value)}
                className="w-full p-2.5 rounded-lg bg-white/5 border border-white/15 text-xs text-white placeholder-white/40 focus:border-trattoria-gold outline-none"
              />
            </div>

            {/* Total */}
            <div className="flex justify-between items-center">
              <span className="font-sans text-xs uppercase tracking-widest text-white/60">Total Bill</span>
              <span className="font-serif text-3xl font-black text-trattoria-gold">₹{subtotal}</span>
            </div>

            {/* Action Buttons */}
            <div className="space-y-2 font-sans text-xs uppercase tracking-wider font-bold">
              {tableId ? (
                // Direct Kitchen Order for Table QR Scans
                <button
                  onClick={() => submitDineInOrder(customerNotes)}
                  className="w-full bg-emerald-700 hover:bg-emerald-800 text-white py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-lg transition-all"
                >
                  <Send className="w-4 h-4" />
                  <span>Send Order to Kitchen (Table {tableId})</span>
                </button>
              ) : (
                // Telephone Call-to-Order for Takeout
                <button
                  onClick={submitCallOrder}
                  className="w-full bg-trattoria-red hover:bg-trattoria-redHover text-white py-3.5 rounded-xl flex items-center justify-center gap-2 shadow-red-glow transition-all"
                >
                  <Phone className="w-4 h-4" />
                  <span>Call to Order (7738009029)</span>
                </button>
              )}

              {/* WhatsApp Alternative */}
              <button
                onClick={submitWhatsAppOrder}
                className="w-full bg-emerald-950/60 hover:bg-emerald-900 border border-emerald-500/40 text-emerald-300 py-3 rounded-xl flex items-center justify-center gap-2 transition-all"
              >
                <MessageCircle className="w-4 h-4" />
                <span>Send Order via WhatsApp</span>
              </button>

              {/* Static UPI QR Payment Display Prompt */}
              <button
                onClick={() => setIsUpiModalOpen(true)}
                className="w-full border border-trattoria-gold/30 hover:border-trattoria-gold text-trattoria-gold py-2.5 rounded-xl flex items-center justify-center gap-2 text-[11px] transition-all"
              >
                <CreditCard className="w-3.5 h-3.5" />
                <span>Offline Payment / Show UPI QR Code</span>
              </button>
            </div>

            <p className="text-[10px] text-center text-white/40 italic">
              No online payment processing fee. Payment handled offline at table/counter via Cash or UPI.
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
