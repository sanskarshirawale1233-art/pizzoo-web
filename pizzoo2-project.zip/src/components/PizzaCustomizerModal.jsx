import React, { useState, useEffect } from 'react';
import { X, Plus, Check } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const PizzaCustomizerModal = ({ pizza, onClose }) => {
  const { addToCart } = useCart();

  const [selectedSize, setSelectedSize] = useState('reg'); // 'reg' | 'med' | 'lrg'
  const [selectedCrust, setSelectedCrust] = useState('Neapolitan Thin (00 Flour)');
  const [sauceLevel, setSauceLevel] = useState('Normal Sauce');
  const [selectedToppings, setSelectedToppings] = useState([]);
  const [specialNotes, setSpecialNotes] = useState('');

  useEffect(() => {
    if (pizza) {
      setSelectedSize('reg');
      setSelectedCrust('Neapolitan Thin (00 Flour)');
      setSauceLevel('Normal Sauce');
      setSelectedToppings([]);
      setSpecialNotes('');
    }
  }, [pizza]);

  if (!pizza) return null;

  const sizeOptions = [
    { key: 'reg', label: 'Small (8" Regular)', price: pizza.reg },
    { key: 'med', label: 'Medium (10" Medium)', price: pizza.med },
    { key: 'lrg', label: 'Large (12" Large)', price: pizza.lrg }
  ];

  const crustOptions = [
    { label: 'Neapolitan Thin (00 Flour)', price: 0 },
    { label: 'Stuffed Cheese Crust', price: 60 },
    { label: 'Gluten-Free Crust', price: 80 }
  ];

  const sauceOptions = ['Normal Sauce', 'Extra Sauce (+₹20)', 'Light Sauce'];

  const toppingOptions = pizza.isVeg ? [
    { name: 'Extra Mozzarella Cheese', price: 40 },
    { name: 'Sliced Jalapeños', price: 30 },
    { name: 'Wild Roasted Mushrooms', price: 35 },
    { name: 'Black Olives', price: 30 },
    { name: 'Tender Paneer Chunks', price: 45 },
    { name: 'Sweet Golden Corn', price: 25 }
  ] : [
    { name: 'Extra Mozzarella Cheese', price: 40 },
    { name: 'Grilled Chicken Chunks', price: 50 },
    { name: 'Chicken Salami Rounds', price: 45 },
    { name: 'Sliced Jalapeños', price: 30 },
    { name: 'Wild Roasted Mushrooms', price: 35 },
    { name: 'Black Olives', price: 30 }
  ];

  const toggleTopping = (topping) => {
    if (selectedToppings.some(t => t.name === topping.name)) {
      setSelectedToppings(selectedToppings.filter(t => t.name !== topping.name));
    } else {
      setSelectedToppings([...selectedToppings, topping]);
    }
  };

  const basePrice = sizeOptions.find(s => s.key === selectedSize)?.price || pizza.reg;
  const crustPrice = crustOptions.find(c => c.label === selectedCrust)?.price || 0;
  const saucePrice = sauceLevel.includes('+₹20') ? 20 : 0;
  const toppingsPrice = selectedToppings.reduce((sum, t) => sum + t.price, 0);

  const totalPrice = basePrice + crustPrice + saucePrice + toppingsPrice;

  const handleAddToCart = () => {
    const sizeObj = sizeOptions.find(s => s.key === selectedSize);
    addToCart({
      id: pizza.id,
      name: pizza.name,
      price: totalPrice,
      size: sizeObj?.label || 'Small (8" Regular)',
      crust: selectedCrust,
      sauceLevel,
      toppings: selectedToppings.map(t => t.name),
      notes: specialNotes,
      quantity: 1,
      isVeg: pizza.isVeg
    });
    onClose();
  };

  return (
    <div className="fixed inset-0 z-[2000] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto animate-fadeIn">
      <div className="bg-[#1A1008] border border-trattoria-gold/30 rounded-3xl max-w-2xl w-full max-h-[90vh] overflow-y-auto shadow-2xl text-white my-auto">
        {/* Header Image */}
        <div className="relative h-64 overflow-hidden rounded-t-3xl">
          <img src={pizza.img} alt={pizza.name} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-[#1A1008] via-transparent to-transparent" />
          <button 
            onClick={onClose}
            className="absolute top-4 right-4 bg-black/60 hover:bg-trattoria-red text-white p-2 rounded-full backdrop-blur-sm transition-all"
          >
            <X className="w-5 h-5" />
          </button>
          <span className={`absolute bottom-4 left-6 px-3 py-1 rounded-full text-xs font-sans font-bold uppercase ${
            pizza.isVeg ? 'bg-emerald-600' : 'bg-red-600'
          }`}>
            {pizza.isVeg ? '🟢 Pure Veg' : '🔴 Non-Veg'}
          </span>
        </div>

        {/* Modal Content */}
        <div className="p-6 md:p-8 space-y-6">
          <div>
            <h2 className="font-serif text-3xl font-black text-white">{pizza.name}</h2>
            <span className="text-trattoria-gold font-sans text-xs italic">{pizza.italianTitle}</span>
            <p className="text-sm text-white/60 font-body mt-2 leading-relaxed">{pizza.desc}</p>
          </div>

          {/* 1. Size Selector */}
          <div>
            <label className="block font-sans text-xs tracking-widest text-trattoria-gold uppercase font-bold mb-3">
              1. Choose Size
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {sizeOptions.map((s) => (
                <button
                  key={s.key}
                  onClick={() => setSelectedSize(s.key)}
                  className={`p-4 rounded-xl border text-left transition-all ${
                    selectedSize === s.key 
                      ? 'border-trattoria-gold bg-trattoria-gold/15 text-white shadow-gold-glow' 
                      : 'border-white/10 bg-white/5 text-white/70 hover:border-white/30'
                  }`}
                >
                  <span className="block font-sans text-xs font-bold uppercase">{s.label}</span>
                  <span className="font-serif text-lg font-bold text-trattoria-gold mt-1 block">₹{s.price}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 2. Crust Type */}
          <div>
            <label className="block font-sans text-xs tracking-widest text-trattoria-gold uppercase font-bold mb-3">
              2. Crust Type
            </label>
            <div className="space-y-2">
              {crustOptions.map((c, i) => (
                <button
                  key={i}
                  onClick={() => setSelectedCrust(c.label)}
                  className={`w-full p-3 rounded-xl border flex justify-between items-center text-xs font-sans transition-all ${
                    selectedCrust === c.label 
                      ? 'border-trattoria-gold bg-trattoria-gold/15 text-white font-bold' 
                      : 'border-white/10 bg-white/5 text-white/70 hover:border-white/20'
                  }`}
                >
                  <span>{c.label}</span>
                  <span className="text-trattoria-gold font-bold">{c.price > 0 ? `+₹${c.price}` : 'Included'}</span>
                </button>
              ))}
            </div>
          </div>

          {/* 3. Sauce Level */}
          <div>
            <label className="block font-sans text-xs tracking-widest text-trattoria-gold uppercase font-bold mb-3">
              3. Sauce Level
            </label>
            <div className="flex flex-wrap gap-2">
              {sauceOptions.map((s, i) => (
                <button
                  key={i}
                  onClick={() => setSauceLevel(s)}
                  className={`px-4 py-2 rounded-lg border text-xs font-sans transition-all ${
                    sauceLevel === s 
                      ? 'border-trattoria-gold bg-trattoria-gold/20 text-white font-bold' 
                      : 'border-white/10 bg-white/5 text-white/60'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          {/* 4. Extra Toppings */}
          <div>
            <label className="block font-sans text-xs tracking-widest text-trattoria-gold uppercase font-bold mb-3">
              4. Extra Toppings
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {toppingOptions.map((t, i) => {
                const isSelected = selectedToppings.some(st => st.name === t.name);
                return (
                  <button
                    key={i}
                    onClick={() => toggleTopping(t)}
                    className={`p-3 rounded-xl border text-xs font-sans flex justify-between items-center transition-all ${
                      isSelected 
                        ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300 font-bold' 
                        : 'border-white/10 bg-white/5 text-white/60 hover:border-white/20'
                    }`}
                  >
                    <span className="flex items-center gap-2">
                      <div className={`w-4 h-4 rounded border flex items-center justify-center ${isSelected ? 'bg-emerald-500 border-emerald-500 text-black' : 'border-white/30'}`}>
                        {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                      </div>
                      {t.name}
                    </span>
                    <span className="text-trattoria-gold font-bold">+₹{t.price}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Special Kitchen Notes */}
          <div>
            <label className="block font-sans text-xs tracking-widest text-trattoria-gold uppercase font-bold mb-2">
              Special Kitchen Instructions
            </label>
            <input
              type="text"
              placeholder="e.g., Extra crispy base, well-done cheese, cut into 8 slices..."
              value={specialNotes}
              onChange={(e) => setSpecialNotes(e.target.value)}
              className="w-full p-3 rounded-xl bg-black/40 border border-white/15 text-xs text-white placeholder-white/40 focus:border-trattoria-gold outline-none"
            />
          </div>

          {/* Modal Footer */}
          <div className="pt-4 border-t border-white/10 flex items-center justify-between gap-4">
            <div>
              <span className="text-[10px] font-sans text-trattoria-gold uppercase tracking-wider block">Total Price</span>
              <span className="font-serif text-3xl font-black text-trattoria-gold">₹{totalPrice}</span>
            </div>

            <button
              onClick={handleAddToCart}
              className="flex-1 bg-trattoria-red hover:bg-trattoria-redHover text-white py-4 rounded-xl font-sans text-xs uppercase tracking-widest font-bold flex items-center justify-center gap-2 shadow-red-glow transition-all hover:scale-102"
            >
              <Plus className="w-4 h-4" />
              <span>Add to Basket (₹{totalPrice})</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
