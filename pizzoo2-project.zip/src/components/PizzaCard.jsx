import React from 'react';
import { Plus, Sparkles } from 'lucide-react';

export const PizzaCard = ({ pizza, onCustomize }) => {
  return (
    <div 
      onClick={() => onCustomize(pizza)}
      className="bg-white/[0.03] border border-white/10 rounded-2xl overflow-hidden hover:-translate-y-2 hover:border-trattoria-gold/50 hover:shadow-trattoria transition-all duration-300 cursor-pointer flex flex-col justify-between group"
    >
      <div>
        {/* Image & Badges */}
        <div className="relative h-48 overflow-hidden">
          <img 
            src={pizza.img} 
            alt={pizza.name} 
            className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" 
            loading="lazy"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-[#0D0700] via-transparent to-transparent opacity-80" />

          {/* Veg / Non-Veg Badge */}
          <span className={`absolute top-3 left-3 px-2.5 py-1 rounded-md font-sans text-[10px] tracking-wider uppercase font-bold text-white shadow-md ${
            pizza.isVeg ? 'bg-emerald-600' : 'bg-red-600'
          }`}>
            {pizza.isVeg ? '● VEG' : '● NON-VEG'}
          </span>

          {/* Special Tag Badges */}
          {pizza.tags && pizza.tags.length > 0 && (
            <span className="absolute top-3 right-3 bg-trattoria-gold/90 text-trattoria-wood px-2.5 py-1 rounded-md font-sans text-[9px] font-black tracking-wider uppercase flex items-center gap-1 shadow-md">
              <Sparkles className="w-3 h-3" />
              {pizza.tags[0]}
            </span>
          )}
        </div>

        {/* Card Body */}
        <div className="p-5">
          <h3 className="font-serif text-xl font-bold text-white group-hover:text-trattoria-gold transition-colors">
            {pizza.name}
          </h3>
          <span className="block font-sans text-[11px] text-trattoria-gold/80 italic mb-2">
            {pizza.italianTitle}
          </span>
          <p className="text-xs text-white/55 font-body line-clamp-2 leading-relaxed mb-4">
            {pizza.desc}
          </p>

          {/* Key ingredients chips */}
          <div className="flex flex-wrap gap-1.5 mb-4">
            {pizza.ingredients?.slice(0, 3).map((ing, i) => (
              <span key={i} className="text-[10px] font-sans bg-white/5 text-white/70 px-2 py-0.5 rounded border border-white/10">
                {ing}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Card Footer */}
      <div className="p-5 pt-0 border-t border-white/5 flex items-center justify-between mt-auto">
        <div>
          <span className="text-[10px] font-sans text-trattoria-gold uppercase tracking-wider block">From</span>
          <span className="font-serif text-2xl font-bold text-trattoria-gold">
            ₹{pizza.reg}
          </span>
        </div>

        <button 
          onClick={(e) => {
            e.stopPropagation();
            onCustomize(pizza);
          }}
          className="bg-trattoria-red hover:bg-trattoria-redHover text-white px-4 py-2.5 rounded-lg font-sans text-xs uppercase tracking-wider font-bold flex items-center gap-1.5 transition-all shadow-red-glow hover:scale-105"
        >
          <Plus className="w-4 h-4" />
          <span>View & Order</span>
        </button>
      </div>
    </div>
  );
};
