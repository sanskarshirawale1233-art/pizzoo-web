import React from 'react';
import { X, Flame, CheckCircle, Clock, UtensilsCrossed } from 'lucide-react';
import { useCart } from '../context/CartContext';

export const LiveOrderStatusModal = () => {
  const { activeOrderTracker, setActiveOrderTracker } = useCart();

  if (!activeOrderTracker) return null;

  const steps = [
    { key: 'RECEIVED', label: 'Order Received', sub: 'Received in Kitchen', icon: Clock },
    { key: 'IN_OVEN', label: 'In Oven', sub: 'Baking in Stone Oven 🍕', icon: Flame },
    { key: 'READY', label: 'Ready for Service', sub: 'Hot & Ready 🔔', icon: CheckCircle },
    { key: 'SERVED', label: 'Served to Table', sub: 'Delivered / Served 🍽️', icon: UtensilsCrossed }
  ];

  const statusOrder = ['RECEIVED', 'IN_OVEN', 'READY', 'SERVED'];
  const currentStepIndex = statusOrder.indexOf(activeOrderTracker.status);

  return (
    <div className="fixed inset-0 z-[2200] bg-black/85 backdrop-blur-md flex items-center justify-center p-4 animate-fadeIn">
      <div className="bg-[#1A1008] border border-trattoria-gold/40 rounded-3xl max-w-lg w-full p-6 md:p-8 shadow-2xl text-white relative">
        <button 
          onClick={() => setActiveOrderTracker(null)}
          className="absolute top-4 right-4 text-white/50 hover:text-white p-2 rounded-full hover:bg-white/10"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="text-center mb-6">
          <span className="font-sans text-xs tracking-widest text-trattoria-gold uppercase block mb-1">
            Real-Time Live Order Progress
          </span>
          <h2 className="font-serif text-3xl font-black text-white">
            {activeOrderTracker.id}
          </h2>
          <span className="inline-block mt-2 px-3 py-1 bg-trattoria-gold/20 border border-trattoria-gold/40 text-trattoria-gold rounded-full font-sans text-xs uppercase font-bold">
            {activeOrderTracker.tableNo !== 'TAKEOUT' ? `Table ${activeOrderTracker.tableNo}` : 'Takeout Order'}
          </span>
        </div>

        {/* Stepper Progress */}
        <div className="space-y-6 my-8 relative before:content-[''] before:absolute before:left-6 before:top-3 before:bottom-3 before:w-0.5 before:bg-white/10">
          {steps.map((s, index) => {
            const isCompleted = index <= currentStepIndex;
            const isCurrent = index === currentStepIndex;
            const IconComp = s.icon;

            return (
              <div key={s.key} className="relative flex items-start gap-4">
                <div className={`w-12 h-12 rounded-2xl flex items-center justify-center font-bold text-sm border z-10 transition-all ${
                  isCurrent 
                    ? 'bg-trattoria-red border-trattoria-gold text-white shadow-red-glow animate-bounce' 
                    : isCompleted 
                    ? 'bg-emerald-600 border-emerald-500 text-white' 
                    : 'bg-black/60 border-white/20 text-white/30'
                }`}>
                  <IconComp className="w-6 h-6" />
                </div>

                <div>
                  <h4 className={`font-sans text-base font-bold uppercase tracking-wider ${
                    isCompleted ? 'text-white' : 'text-white/40'
                  }`}>
                    {s.label}
                  </h4>
                  <p className="text-xs font-body text-trattoria-gold/80 mt-0.5">{s.sub}</p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Order Summary List */}
        <div className="bg-black/40 border border-white/10 rounded-2xl p-4 text-xs font-sans space-y-2">
          <span className="text-trattoria-gold uppercase tracking-wider font-bold block mb-2">Order Breakdown:</span>
          {activeOrderTracker.items?.map((item, idx) => (
            <div key={idx} className="flex justify-between text-white/80">
              <span>{item.quantity}x {item.name} ({item.size})</span>
            </div>
          ))}
        </div>

        <button 
          onClick={() => setActiveOrderTracker(null)}
          className="w-full mt-6 border border-trattoria-gold/40 hover:bg-trattoria-gold hover:text-black text-trattoria-gold py-3 rounded-xl font-sans text-xs uppercase tracking-widest font-bold transition-all"
        >
          Close Tracker
        </button>
      </div>
    </div>
  );
};
