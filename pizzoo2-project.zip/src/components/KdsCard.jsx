import React, { useState, useEffect } from 'react';
import { Clock, RotateCcw, Check, Flame, AlertTriangle, Archive, Utensils } from 'lucide-react';
import { useKds } from '../context/KdsContext';

export const KdsCard = ({ order }) => {
  const { advanceOrderStatus, revertOrderStatus, archiveOrder } = useKds();
  const [elapsedMinutes, setElapsedMinutes] = useState(0);

  // Real-time timer logic
  useEffect(() => {
    const updateTimer = () => {
      const created = new Date(order.createdAt).getTime();
      const now = new Date().getTime();
      setElapsedMinutes(Math.floor((now - created) / 60000));
    };

    updateTimer();
    const interval = setInterval(updateTimer, 10000); // Refresh every 10 seconds
    return () => clearInterval(interval);
  }, [order.createdAt]);

  // Italian status badge colors
  const statusStyles = {
    RECEIVED: { label: 'RICEVUTO (New Order)', color: 'bg-emerald-600 text-white' },
    IN_OVEN: { label: 'IN FORNO (Baking 🍕)', color: 'bg-amber-500 text-white animate-pulse' },
    READY: { label: 'PRONTO (Service Ready 🔔)', color: 'bg-blue-600 text-white' },
    SERVED: { label: 'SERVITO (Done 🍽️)', color: 'bg-slate-600 text-white' }
  };

  // Urgency indicator based on time elapsed
  const getTimerStyle = () => {
    if (elapsedMinutes >= 20) return 'text-red-500 font-black animate-bounce flex items-center gap-1 bg-red-950/60 px-2.5 py-1 rounded border border-red-500/40';
    if (elapsedMinutes >= 10) return 'text-amber-400 font-bold flex items-center gap-1 bg-amber-950/60 px-2 py-0.5 rounded';
    return 'text-emerald-400 font-semibold flex items-center gap-1';
  };

  // Card border highlight based on urgency
  const getCardBorder = () => {
    if (order.status === 'SERVED') return 'border-slate-700 bg-[#120B03]';
    if (elapsedMinutes >= 20) return 'border-red-600 bg-red-950/10 shadow-[0_0_20px_rgba(220,38,38,0.2)]';
    if (elapsedMinutes >= 10) return 'border-amber-500 bg-amber-950/10';
    return 'border-emerald-600/60 bg-[#1A1008]';
  };

  return (
    <div className={`border-2 rounded-2xl p-5 flex flex-col justify-between shadow-2xl transition-all ${getCardBorder()}`}>
      {/* Card Header */}
      <div>
        <div className="flex justify-between items-start border-b border-white/10 pb-3 mb-3">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-2xl font-black font-serif text-white">{order.id}</span>
              <span className={`text-[11px] font-sans font-bold px-2.5 py-0.5 rounded uppercase tracking-wider ${
                order.type === 'DINE_IN' ? 'bg-trattoria-red text-white' : 'bg-trattoria-gold text-trattoria-wood'
              }`}>
                {order.type === 'DINE_IN' ? `Table ${order.tableNo}` : 'Takeout Order'}
              </span>
            </div>
            <span className="text-xs text-white/50 font-body block mt-1">
              {order.customerName}
            </span>
          </div>

          {/* Urgency Timer */}
          <div className={`text-xs font-sans ${getTimerStyle()}`}>
            {elapsedMinutes >= 20 && <AlertTriangle className="w-3.5 h-3.5 text-red-500" />}
            <Clock className="w-3.5 h-3.5" />
            <span>⏱️ {elapsedMinutes}m min</span>
          </div>
        </div>

        {/* Current Status Badge */}
        <div className={`text-center py-1.5 rounded-lg font-sans font-bold text-xs tracking-widest uppercase mb-4 shadow-sm ${statusStyles[order.status].color}`}>
          {statusStyles[order.status].label}
        </div>

        {/* Ordered Items List */}
        <ul className="space-y-2 mb-4 max-h-60 overflow-y-auto pr-1">
          {order.items?.map((item, idx) => (
            <li key={idx} className="bg-black/50 p-3 rounded-xl border border-white/10 text-xs">
              <div className="flex justify-between items-start">
                <span className="font-bold text-white font-sans text-sm">
                  {item.quantity}x {item.name}
                </span>
                <span className="text-[10px] text-trattoria-gold font-sans uppercase font-semibold">
                  {item.size}
                </span>
              </div>
              
              {item.crust && (
                <div className="text-[11px] text-amber-300 font-sans mt-0.5">
                  Crust: {item.crust}
                </div>
              )}

              {item.toppings && item.toppings.length > 0 && (
                <div className="text-[10px] text-white/60 italic mt-0.5">
                  Toppings: {item.toppings.join(', ')}
                </div>
              )}

              {item.notes && (
                <div className="text-[10px] text-emerald-300 italic mt-1 bg-emerald-950/40 p-1.5 rounded border border-emerald-500/20">
                  Notes: "{item.notes}"
                </div>
              )}
            </li>
          ))}
        </ul>

        {/* Kitchen Special Notes */}
        {order.notes && (
          <div className="bg-amber-950/30 border-l-4 border-amber-500 p-2.5 rounded-r-lg text-xs text-amber-200 font-body mb-4">
            <strong className="font-sans uppercase text-[10px] tracking-wider block text-amber-400">Kitchen Instructions:</strong>
            {order.notes}
          </div>
        )}
      </div>

      {/* Control Actions */}
      <div className="flex gap-2 pt-3 border-t border-white/10 mt-auto font-sans text-xs">
        {order.status !== 'RECEIVED' && (
          <button 
            onClick={() => revertOrderStatus(order.id)}
            className="px-3 py-2.5 bg-white/10 hover:bg-white/20 text-white/80 rounded-xl font-bold flex items-center gap-1 transition-colors"
            title="Revert to previous status"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Indietro</span>
          </button>
        )}

        {order.status !== 'SERVED' ? (
          <button 
            onClick={() => advanceOrderStatus(order.id)}
            className="flex-1 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 shadow-lg transition-all"
          >
            {order.status === 'RECEIVED' && (
              <>
                <Flame className="w-4 h-4 text-amber-300" />
                <span>Invia in Forno 🍕</span>
              </>
            )}
            {order.status === 'IN_OVEN' && (
              <>
                <Check className="w-4 h-4" />
                <span>Segna Pronto 🔔</span>
              </>
            )}
            {order.status === 'READY' && (
              <>
                <Utensils className="w-4 h-4" />
                <span>Servito 🍽️</span>
              </>
            )}
          </button>
        ) : (
          <button 
            onClick={() => archiveOrder(order.id)}
            className="flex-1 py-2.5 bg-slate-700 hover:bg-slate-800 text-white rounded-xl font-bold uppercase tracking-wider flex items-center justify-center gap-1.5 transition-all"
          >
            <Archive className="w-4 h-4" />
            <span>Archivia Ordine 📁</span>
          </button>
        )}
      </div>
    </div>
  );
};
